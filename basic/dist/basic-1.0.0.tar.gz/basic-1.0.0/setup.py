from distutils.core import setup
setup(
		name			=	'basic',
		version			=	'1.0.0',
		py_modules		=	['basic'],
		author			=	'김용범',
		author_email	=	'maknee@naver.com',
		url				=	'http://www.twodal.com',
		description		=	'개발자를 위한 기본 모듈'
)
