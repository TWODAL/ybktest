from distutils.core import setup
setup(
		name			=	'tdfile',
		version			=	'1.0.0',
		py_modules		=	['tdfile'],
		author			=	'김용범',
		author_email	=	'maknee@naver.com',
		url				=	'http://www.twodal.com',
		description		=	'file 관련 모듈'
)
